<?php Array
(
    [responseId] => 90bdf3af-7884-4b70-8c42-32cbeb853a19
    [queryResult] => Array
        (
            [queryText] => FACEBOOK_MEDIA
            [parameters] => Array
                (
                )

            [allRequiredParamsPresent] => 1
            [fulfillmentMessages] => Array
                (
                    [0] => Array
                        (
                            [text] => Array
                                (
                                    [text] => Array
                                        (
                                            [0] => 
                                        )

                                )

                        )

                )

            [outputContexts] => Array
                (
                    [0] => Array
                        (
                            [name] => projects/bot-demo-4d232/agent/sessions/8cfa14d4-3537-4afa-94e1-f5b08a869192/contexts/facebook_media
                        )

                    [1] => Array
                        (
                            [name] => projects/bot-demo-4d232/agent/sessions/8cfa14d4-3537-4afa-94e1-f5b08a869192/contexts/generic
                            [lifespanCount] => 4
                            [parameters] => Array
                                (
                                    [facebook_sender_id] => 1076283829163074
                                )

                        )

                )

            [intent] => Array
                (
                    [name] => projects/bot-demo-4d232/agent/intents/d76b37fc-d954-4a86-8f49-2843c6b13087
                    [displayName] => imagen
                )

            [intentDetectionConfidence] => 1
            [languageCode] => es
        )

    [originalDetectIntentRequest] => Array
        (
            [source] => facebook
            [payload] => Array
                (
                    [data] => Array
                        (
                            [sender] => Array
                                (
                                    [id] => 1076283829163074
                                )

                            [recipient] => Array
                                (
                                    [id] => 301735143750953
                                )

                            [message] => Array
                                (
                                    [attachments] => Array
                                        (
                                            [0] => Array
                                                (
                                                    [payload] => Array
                                                        (
                                                            [url] => https://scontent.xx.fbcdn.net/v/t1.15752-9/44980881_2396912037016338_2585147133359292416_n.jpg?_nc_cat=108&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03dbc06084fa84ece22c13d6ae44e84f&oe=5C3F7A00
                                                        )

                                                    [type] => image
                                                )

                                        )

                                    [mid] => 87xror4H2gVeZKUexDlhxXsz8f-G-Au6ANyR6cxRQEp-874_iNxTKVbQdMHjegK6UHhUKoqdGJWCsancgQj_gA
                                    [seq] => 2983
                                )

                            [timestamp] => 1540779486333
                        )

                    [source] => facebook
                )

        )

    [session] => projects/bot-demo-4d232/agent/sessions/8cfa14d4-3537-4afa-94e1-f5b08a869192
)
